# Write a R program to create a sequence of numbers from 20
# to 50 and find the mean of numbers from 20 to 50 and sum
# of numbers.

series <- seq(20:50)
avg <- mean(series)
mysum <- sum(series)
avg
mysum
