# Write a R program to create a vector which contains 10
# random integer values between -50 and +50

vector = c(as.integer(runif(10, min=-50, max=50)))
# could have used the sample function as well!)

vector