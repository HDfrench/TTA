# Create a simple bar plot of five subjects

subjects <- c("Maths", "English", "History", "Science", "Geography")
grades <- c(49,85,98,61,72)
png(file = "GCSE result_bar chart.png")
barplot(grades,names.arg=subjects,xlab="subjects",ylab="Percentage",col="blue", main="GCSE results")
dev.off()