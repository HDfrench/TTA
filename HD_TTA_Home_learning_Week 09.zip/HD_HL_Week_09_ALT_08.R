# Write a R program to get the first 10 Fibonacci numbers.

fib = c()

for (i in 1:10)
  if (i==1 | i == 2)
  {
    fib[i] <- 1
  } else
  {
    fib[i] <- (fib[i-1] + fib[i-2])
  }

fib