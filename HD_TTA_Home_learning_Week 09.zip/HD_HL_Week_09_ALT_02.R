# Write a R program to create a Data frame which contains
# details of 5 employees and display the details. (Name, Age,
# Role and Length of service).

firstname <- c("John", "Mary", "Edward", "Louise", "Joe")
lastname <- c("Lewis", "Dawson", "Oakes", "Reese", "Atkins")
age <- c(28, 35, 29, 43, 19)
role <- c("Lead salesperson", "Head of Marketing", "IT supervisor", "CEO", "Junior programer")
enlist <- c(3, 9, 5, 14, 1)

frame <- data.frame(lastname, firstname, role, age, enlist)
frame