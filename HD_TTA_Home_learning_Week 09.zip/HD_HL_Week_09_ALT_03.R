# Import the GGPLOT 2 library and plot a graph using the qplot
# function. X axis is the sequence of 1:20 and the y axis is the x^2. 
# Label the graph appropriately. install.packages("ggplot2", dependencies = TRUE)

library(ggplot2)
data <- seq(1:20)
png(file = "squared number curve.png")
qplot(data, data^2, geom = "line", main = "Squares of number from 1 to 20", xlab = "number", ylab = "squared number", col = "red")
dev.off()