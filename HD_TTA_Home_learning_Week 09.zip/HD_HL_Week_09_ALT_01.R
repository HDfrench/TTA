# Write an R program to create three vectors a, b, c with 5
# integers. Combine the three vectors to become a 3×5 matrix
# where each column represents a vector. Print the content of
# the matrix. Plot a graph and label correctly.

a <- c(1,2,3,4,5)
b <- c(6,7,8,9,10)
c <- c(11,12,13,14,15)

png(file = "Matrix value by row.png")
mymatrix <- cbind(a, b, c)
mymatrix
mp <- matplot(mymatrix, type ="b", pch=15, col=1:3, 
              xlab = "Row number", ylab = "Content value", 
              main = "Matrix value by row", 
              font.main=4, col.main="red", cex.main = 2.5,
              font.lab=12, col.lab="blue", cex.lab = 1)
legend("topleft", legend = c("row 1", "row 2", "row 3"), lty = 1, col = 1:3, cex=0.8)
dev.off()