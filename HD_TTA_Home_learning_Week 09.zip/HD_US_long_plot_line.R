# Using the ggplot in-built data sets in RStudio and the qplot
# function, get your creative juices flowing and create a meaningful
# and impactful data visualization using your preferred data set.

library(ggplot2)

#data(package = "ggplot2")

#ggplot2::economics_long
png(file = "US economic historical data 1965-2016.png")
p <- qplot(data = economics_long, x = date, y = value01, geom = "line", color = variable)
p + labs( x = "Year", y = "Proportion",  title = "US economy", subtitle = "historical data 1965 - 2016", colour= "Components", caption = "(based on data from ggplot2::economics_long)")
dev.off()