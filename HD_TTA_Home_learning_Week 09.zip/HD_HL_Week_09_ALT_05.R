# Write a R program to take input from the user (name and
# age) and display the values.

name <- readline("What is your name? ")
age <- readline("How old are you? ")

hello <- paste ("Your name is", name)
display <- paste("and you are", age, "years young!")
print(hello)
print(display)
